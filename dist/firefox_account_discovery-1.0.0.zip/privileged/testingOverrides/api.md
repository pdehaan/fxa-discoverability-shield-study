# Namespace: `browser.testingOverrides`

Accesses preferences used to set studySetup testing flags

## Functions

### `browser.testingOverrides.getVariationNameOverride( )`

**Parameters**

### `browser.testingOverrides.getFirstRunTimestampOverride( )`

**Parameters**

### `browser.testingOverrides.getExpiredOverride( )`

**Parameters**

### `browser.testingOverrides.listPreferences( )`

**Parameters**

## Events

(None)

## Properties TBD

## Data Types

(None)
